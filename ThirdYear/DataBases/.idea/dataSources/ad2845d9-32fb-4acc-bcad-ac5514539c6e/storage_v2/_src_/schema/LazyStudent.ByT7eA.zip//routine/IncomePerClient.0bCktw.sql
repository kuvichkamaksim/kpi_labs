create
  definer = maksim@`%` procedure IncomePerClient(IN clientName varchar(50))
BEGIN
        
        DECLARE currClientID INTEGER;
        
        SELECT `ClientID` FROM Clients WHERE CONCAT(`FirstName`, ' ', `LastName`) = clientName INTO currClientID;
        
        SELECT * FROM Orders JOIN Clients C ON Orders.ClientID = C.ClientID
          WHERE C.ClientID = currClientID;

      END;

