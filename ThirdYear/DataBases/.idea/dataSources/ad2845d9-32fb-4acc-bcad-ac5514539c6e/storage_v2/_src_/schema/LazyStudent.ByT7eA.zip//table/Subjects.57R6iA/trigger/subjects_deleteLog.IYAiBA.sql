create definer = maksim@`%` trigger subjects_deleteLog
  after DELETE
  on Subjects
  for each row
BEGIN

        INSERT INTO Subjects_deleted(`UserWhoDelete`, `DeleteDate`, `SubjectID`, `SubjectName`, `Price`)
        VALUES(USER(), NOW(), OLD.`SubjectID`, OLD.`SubjectName`, OLD.`Price`);

        END;

