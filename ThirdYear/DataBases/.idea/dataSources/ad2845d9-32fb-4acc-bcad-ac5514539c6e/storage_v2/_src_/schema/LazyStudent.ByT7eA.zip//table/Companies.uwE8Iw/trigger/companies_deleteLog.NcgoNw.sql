create definer = maksim@`%` trigger companies_deleteLog
  after DELETE
  on Companies
  for each row
BEGIN

        INSERT INTO Companies_deleted(`UserWhoDelete`, `DeleteDate`, `CompanyID`, `CompanyName`, `PhoneNumber`,
                                      `E-mail`, `ReservePhoneNumber`, `CourseID`)
        VALUES(USER(), NOW(), OLD.`CompanyID`, OLD.`CompanyName`, OLD.`PhoneNumber`, OLD.`E-mail`,
               OLD.`ReservePhoneNumber`, OLD.`CourseID`);

        END;

