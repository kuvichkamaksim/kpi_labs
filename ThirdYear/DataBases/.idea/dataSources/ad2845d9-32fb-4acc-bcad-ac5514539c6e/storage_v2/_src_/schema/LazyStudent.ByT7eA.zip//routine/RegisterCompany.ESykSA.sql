create
  definer = maksim@`%` procedure RegisterCompany(IN compName varchar(40), IN phone varchar(15), IN email varchar(30),
                                                 IN secondPhone varchar(15), IN courseName varchar(30))
BEGIN

        DECLARE currCourseID INTEGER;
        SELECT CourseID FROM Courses WHERE Courses.CourseName = courseName INTO currCourseID;

        INSERT INTO Companies(`CompanyName`, `PhoneNumber`, `E-mail`, `ReservePhoneNumber`, `CourseID`)
          VALUES(compName, phone, email, secondPhone, currCourseID);

      END;

