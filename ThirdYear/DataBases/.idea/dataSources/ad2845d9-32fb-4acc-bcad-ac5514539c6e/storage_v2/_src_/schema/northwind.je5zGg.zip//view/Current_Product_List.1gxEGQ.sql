create definer = root@localhost view `Current Product List` as
select `northwind`.`Products`.`ProductID` AS `ProductID`, `northwind`.`Products`.`ProductName` AS `ProductName`
from `northwind`.`Products`
where `northwind`.`Products`.`Discontinued` = 0;

