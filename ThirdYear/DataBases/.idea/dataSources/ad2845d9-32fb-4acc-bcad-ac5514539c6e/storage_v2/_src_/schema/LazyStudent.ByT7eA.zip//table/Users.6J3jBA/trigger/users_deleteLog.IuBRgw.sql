create definer = maksim@`%` trigger users_deleteLog
  after DELETE
  on Users
  for each row
BEGIN

        INSERT INTO Users_deleted(`UserWhoDelete`, `DeleteDate`, `UserID`, `UserType`, `Login`, `Password`,
                                  `PhoneNumber`,`E-mail`, `ReservePhoneNumber`)
        VALUES(USER(), NOW(), OLD.`UserID`, OLD.`UserType`, OLD.`Login`, OLD.`Password`, OLD.`PhoneNumber`,
               OLD.`E-mail`, OLD.`ReservePhoneNumber`);

        END;

