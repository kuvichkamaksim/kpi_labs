create
  definer = root@localhost function toPascalCase(string varchar(30)) returns varchar(30)
BEGIN
  DECLARE res VARCHAR(30) DEFAULT '';
  DECLARE pos INTEGER DEFAULT 1;
  DECLARE curr VARCHAR(1);
  SET string = LOWER(string);

  WHILE pos <= LENGTH(string)
  DO
    SET curr = SUBSTRING(string, pos, 1);
    IF curr REGEXP '^[A-Z]+$' = 1 THEN

      IF SUBSTRING(string, pos-1, 1) REGEXP '^[A-Z]+$' = 0 THEN
        SET res = CONCAT( res, UPPER(curr) );
      ELSE
        SET res = CONCAT( res, curr );
      END IF;

    END IF;
    SET pos = pos + 1;
  END WHILE;

 RETURN res;

END;

