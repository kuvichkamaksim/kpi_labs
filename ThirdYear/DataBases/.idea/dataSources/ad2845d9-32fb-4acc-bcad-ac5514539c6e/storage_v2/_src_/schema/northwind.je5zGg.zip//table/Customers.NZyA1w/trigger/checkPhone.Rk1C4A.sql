create definer = maksim@`%` trigger checkPhone
  before INSERT
  on Customers
  for each row
  SET NEW.Phone = REGEXP_REPLACE(NEW.Phone, '[^0-9]', '');

