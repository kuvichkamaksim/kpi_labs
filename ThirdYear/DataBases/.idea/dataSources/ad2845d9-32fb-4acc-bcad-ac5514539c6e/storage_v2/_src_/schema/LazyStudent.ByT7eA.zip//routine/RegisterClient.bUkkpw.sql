create
  definer = maksim@`%` procedure RegisterClient(IN login varchar(30), IN password varchar(30), IN firstName varchar(20),
                                                IN lastName varchar(30), IN phone varchar(15), IN email varchar(30),
                                                IN secondPhone varchar(15))
BEGIN
  INSERT INTO Users(`UserType`, `Login`, `Password`, `PhoneNumber`, `E-mail`, `ReservePhoneNumber`)
    VALUES("Client", login, password, phone, email, secondPhone);
  INSERT INTO Clients(`LastName`, `FirstName`)
    VALUES(lastName, firstName);
END;

