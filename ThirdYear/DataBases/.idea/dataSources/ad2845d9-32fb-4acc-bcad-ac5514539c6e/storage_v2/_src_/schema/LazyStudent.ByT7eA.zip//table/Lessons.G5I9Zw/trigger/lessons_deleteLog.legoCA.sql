create definer = maksim@`%` trigger lessons_deleteLog
  after DELETE
  on Lessons
  for each row
BEGIN

        INSERT INTO Lessons_deleted(`UserWhoDelete`, `DeleteDate`, `LessonID`, `TutorID`, `SubjectID`)
        VALUES(USER(), NOW(), OLD.`LessonID`, OLD.`TutorID`, OLD.`SubjectID`);

        END;

