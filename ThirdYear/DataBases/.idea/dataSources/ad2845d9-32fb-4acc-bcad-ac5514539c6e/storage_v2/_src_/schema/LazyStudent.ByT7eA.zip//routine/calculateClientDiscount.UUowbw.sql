create
  definer = maksim@`%` function calculateClientDiscount(currClientID int) returns float(3, 2)
BEGIN

        DECLARE regDate DATETIME;
        DECLARE yearDiff INTEGER;
        SELECT `RegisterDate` FROM Clients
          WHERE `ClientID` = currClientID
          INTO regDate;
        SELECT TIMESTAMPDIFF(YEAR, regDate, NOW())
          INTO yearDiff;

        IF yearDiff < 1 THEN
          RETURN 0.00;
        ELSEIF yearDiff  = 1 THEN
          RETURN 0.05;
        ELSEIF yearDiff = 2 THEN
          RETURN 0.08;
        ELSEIF yearDiff = 3 THEN
          RETURN 0.11;
        ELSE RETURN 0.15;
        END IF;

      END;

