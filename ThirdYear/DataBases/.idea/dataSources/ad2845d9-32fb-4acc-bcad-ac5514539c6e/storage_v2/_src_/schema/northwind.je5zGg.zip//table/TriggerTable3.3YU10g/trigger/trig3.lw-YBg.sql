create definer = maksim@`%` trigger trig3
  after INSERT
  on TriggerTable3
  for each row
BEGIN
    INSERT INTO TriggerTable1(TriggerDate)
    VALUES (NOW());
  END;

