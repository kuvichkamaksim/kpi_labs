create
  definer = maksim@`%` procedure IncomePerTutor(IN tutorName varchar(50))
BEGIN

        DECLARE currTutorID INTEGER;

        SELECT `TutorID` FROM Tutors WHERE CONCAT(`FirstName`, ' ', `LastName`) = tutorName INTO currTutorID;

        SELECT * FROM Orders
          JOIN Lessons L on Orders.LessonID = L.LessonID
          WHERE L.`TutorID` = currTutorID;

      END;

