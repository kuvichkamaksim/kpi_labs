create
  definer = maksim@`%` procedure RegisterDiscount(IN discValue float(3, 2), IN start datetime, IN end datetime,
                                                  IN compName varchar(40))
BEGIN
          
          DECLARE currCompanyID INTEGER;
          
          SELECT `CompanyID` FROM Companies WHERE `CompanyName` = compName INTO currCompanyID;

          INSERT INTO Discounts(`DiscountValue`, `CompanyID`, `StartDate`, `EndDate`)
            VALUES(discValue, currCompanyID, start, end);
             
        END;

