create definer = root@localhost view `Product Sales for 1997` as
select `northwind`.`Categories`.`CategoryName`                       AS `CategoryName`,
       `northwind`.`Products`.`ProductName`                          AS `ProductName`,
       sum(`northwind`.`Order Details`.`UnitPrice` * `northwind`.`Order Details`.`Quantity` *
           (1 - `northwind`.`Order Details`.`Discount`) / 100 * 100) AS `ProductSales`
from (((`northwind`.`Categories` join `northwind`.`Products` on (`northwind`.`Categories`.`CategoryID` =
                                                                 `northwind`.`Products`.`CategoryID`)) join `northwind`.`Order Details` on (
    `northwind`.`Products`.`ProductID` = `northwind`.`Order Details`.`ProductID`))
       join `northwind`.`Orders` on (`northwind`.`Orders`.`OrderID` = `northwind`.`Order Details`.`OrderID`))
where `northwind`.`Orders`.`ShippedDate` between '1997-01-01' and '1997-12-31'
group by `northwind`.`Categories`.`CategoryName`, `northwind`.`Products`.`ProductName`;

