create definer = maksim@`%` trigger storeDeletedInfo
  after DELETE
  on Orders
  for each row
BEGIN
    INSERT INTO OrdersArchive(OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight,
                               ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry,
                               DeletionDateTime, DeletedBy)
    VALUES(OLD.OrderID, OLD.CustomerID, OLD.EmployeeID, OLD.OrderDate, OLD.RequiredDate, OLD.ShippedDate, OLD.ShipVia,
            OLD.Freight, OLD.ShipName, OLD.ShipAddress, OLD.ShipCity, OLD.ShipRegion, OLD.ShipPostalCode,
            OLD.ShipCountry, NOW(), CURRENT_USER());
  END;

