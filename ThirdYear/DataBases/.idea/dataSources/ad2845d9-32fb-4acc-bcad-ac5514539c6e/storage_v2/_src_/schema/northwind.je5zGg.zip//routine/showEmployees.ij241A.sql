create
  definer = root@localhost procedure showEmployees(IN gender varchar(1))
BEGIN
  IF gender = 'F' OR gender = 'f' THEN
    SELECT FirstName, LastName FROM Employees
      WHERE TitleOfCourtesy = 'Ms.' OR TitleOfCourtesy = 'Mrs.';

  ELSEIF gender = 'M' OR gender = 'm' THEN
    SELECT FirstName, LastName FROM Employees
      WHERE TitleOfCourtesy = 'Mr.' OR TitleOfCourtesy = 'Dr.';

  ELSE
    SELECT 'Message was not interpreted.';

  END IF;
END;

