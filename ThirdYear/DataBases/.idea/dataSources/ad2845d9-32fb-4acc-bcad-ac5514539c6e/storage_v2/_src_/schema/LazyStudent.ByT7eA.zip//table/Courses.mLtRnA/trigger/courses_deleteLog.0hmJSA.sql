create definer = maksim@`%` trigger courses_deleteLog
  after DELETE
  on Courses
  for each row
BEGIN

        INSERT INTO Courses_deleted(`UserWhoDelete`, `DeleteDate`, `CourseID`, `CourseName`, `Price`)
        VALUES(USER(), NOW(), OLD.`CourseID`, OLD.`CourseName`, OLD.`Price`);

        END;

