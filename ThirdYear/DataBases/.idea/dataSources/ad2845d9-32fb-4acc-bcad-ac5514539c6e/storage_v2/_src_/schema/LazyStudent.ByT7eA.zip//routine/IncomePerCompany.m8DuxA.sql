create
  definer = maksim@`%` procedure IncomePerCompany(IN compName varchar(50))
BEGIN

        DECLARE currCompanyID INTEGER;

        SELECT `CompanyID` FROM Companies WHERE `CompanyName` = compName INTO currCompanyID;

        SELECT * FROM Orders JOIN Companies C ON Orders.CompanyID = C.CompanyID
          WHERE C.CompanyID = currCompanyID;

      END;

