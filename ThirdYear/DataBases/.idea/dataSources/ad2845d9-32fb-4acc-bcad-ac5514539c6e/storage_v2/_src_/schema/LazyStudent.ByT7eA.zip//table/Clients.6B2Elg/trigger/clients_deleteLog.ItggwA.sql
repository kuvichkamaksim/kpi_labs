create definer = maksim@`%` trigger clients_deleteLog
  after DELETE
  on Clients
  for each row
BEGIN

        INSERT INTO Clients_deleted(`UserWhoDelete`, `DeleteDate`, `ClientID`, `LastName`, `FirstName`, `RegisterDate`,
                                    `UserID`)
        VALUES(USER(), NOW(), OLD.`ClientID`, OLD.`LastName`, OLD.`FirstName`, OLD.`RegisterDate`, OLD.`UserID`);

        END;

