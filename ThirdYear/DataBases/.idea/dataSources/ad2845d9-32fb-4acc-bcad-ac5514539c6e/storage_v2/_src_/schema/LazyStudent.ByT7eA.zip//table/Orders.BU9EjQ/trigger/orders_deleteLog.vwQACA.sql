create definer = maksim@`%` trigger orders_deleteLog
  after DELETE
  on Orders
  for each row
BEGIN

        INSERT INTO Orders_deleted(`UserWhoDelete`, `DeleteDate`, `OrderID`, `ClientID`, `LessonID`, `CompanyID`,
                                      `CourseID`, `StartDate`, `EndDate`, `Price`, `DiscountID`, `ClientDiscount`)
        VALUES(USER(), NOW(), OLD.`OrderID`, OLD.`ClientID`, OLD.`LessonID`, OLD.`CompanyID`, OLD.`CourseID`,
               OLD.`StartDate`, OLD.`EndDate`, OLD.`Price`, OLD.`DiscountID`, OLD.`ClientDiscount`);

        END;

