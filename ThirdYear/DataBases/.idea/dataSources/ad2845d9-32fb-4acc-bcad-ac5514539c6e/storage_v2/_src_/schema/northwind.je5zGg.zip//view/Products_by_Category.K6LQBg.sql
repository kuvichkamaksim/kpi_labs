create definer = root@localhost view `Products by Category` as
select `northwind`.`Categories`.`CategoryName`  AS `CategoryName`,
       `northwind`.`Products`.`ProductName`     AS `ProductName`,
       `northwind`.`Products`.`QuantityPerUnit` AS `QuantityPerUnit`,
       `northwind`.`Products`.`UnitsInStock`    AS `UnitsInStock`,
       `northwind`.`Products`.`Discontinued`    AS `Discontinued`
from (`northwind`.`Categories`
       join `northwind`.`Products` on (`northwind`.`Categories`.`CategoryID` = `northwind`.`Products`.`CategoryID`))
where `northwind`.`Products`.`Discontinued` <> 1;

