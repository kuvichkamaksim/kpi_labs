create
  definer = root@localhost function calculateFullPrice(UnitPrice float(5, 2), Quantity int, Discount float(3, 2)) returns float(10, 5)
IF Discount <= 1 AND Discount >= 0 THEN
  RETURN UnitPrice * Quantity * (1 - Discount);
END IF;

