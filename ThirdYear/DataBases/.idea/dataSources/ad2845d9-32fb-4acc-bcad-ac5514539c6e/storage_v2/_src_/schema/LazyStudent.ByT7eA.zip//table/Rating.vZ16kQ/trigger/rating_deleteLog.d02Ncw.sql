create definer = maksim@`%` trigger rating_deleteLog
  after DELETE
  on Rating
  for each row
BEGIN

        INSERT INTO Rating_deleted(`UserWhoDelete`, `DeleteDate`, `RecordID`, `ClientID`, `TutorID`, `Rating`)
        VALUES(USER(), NOW(), OLD.`RecordID`, OLD.`ClientID`, OLD.`TutorID`, OLD.`Rating`);

        END;

