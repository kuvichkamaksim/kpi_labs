create definer = maksim@`%` trigger trig2
  after INSERT
  on TriggerTable2
  for each row
BEGIN
    INSERT INTO TriggerTable3(TriggerDate)
    VALUES (NOW());
  END;

