create
  definer = root@localhost procedure showOrdersInPeriod(IN startDate datetime, IN endDate datetime)
BEGIN

    IF endDate IS NULL THEN
      SELECT * FROM Orders
        WHERE OrderDate = startDate;

    ELSEIF startDate IS NULL THEN
      SELECT * FROM Orders
        WHERE OrderDate = endDate;

    ELSE
      SELECT * FROM Orders
        WHERE OrderDate BETWEEN startDate AND endDate;
    END IF;

END;

