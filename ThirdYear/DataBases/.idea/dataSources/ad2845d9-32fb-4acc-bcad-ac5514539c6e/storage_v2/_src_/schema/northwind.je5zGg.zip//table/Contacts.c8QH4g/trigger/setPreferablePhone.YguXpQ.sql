create definer = maksim@`%` trigger setPreferablePhone
  before INSERT
  on Contacts
  for each row
BEGIN
    IF NEW.WorkPhone IS NOT NULL THEN
      SET NEW.PreferableNumber = NEW.WorkPhone;
    ELSE
      SET NEW.PreferableNumber = NEW.PersonalPhone;
    END IF;
  END;

