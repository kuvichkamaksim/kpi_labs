create
  definer = root@localhost procedure findEmployeeFrom(IN country varchar(15))
BEGIN
  SELECT * FROM Employees WHERE Country = country;
END;

