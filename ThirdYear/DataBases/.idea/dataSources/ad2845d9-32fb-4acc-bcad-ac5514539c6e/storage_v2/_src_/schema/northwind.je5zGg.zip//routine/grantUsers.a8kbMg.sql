create
  definer = maksim@`%` procedure grantUsers()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE userName VARCHAR(30);
  DECLARE currentUser CURSOR FOR SELECT DISTINCT User FROM mysql.user;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN currentUser;

  read_loop: LOOP
    FETCH currentUser INTO userName;

    IF done THEN
      LEAVE read_loop;
    END IF;

    EXECUTE IMMEDIATE CONCAT('GRANT SELECT ON northwind.* TO ', userName);
  END LOOP;

  CLOSE currentUser;
END;

