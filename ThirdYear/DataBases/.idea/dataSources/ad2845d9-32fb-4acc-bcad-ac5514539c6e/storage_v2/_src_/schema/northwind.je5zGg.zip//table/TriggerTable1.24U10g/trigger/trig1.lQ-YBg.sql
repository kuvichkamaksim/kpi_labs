create definer = maksim@`%` trigger trig1
  after INSERT
  on TriggerTable1
  for each row
BEGIN
    INSERT INTO TriggerTable2(TriggerDate)
    VALUES (NOW());
  END;

