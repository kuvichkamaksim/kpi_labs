create definer = maksim@`%` trigger tutors_deleteLog
  after DELETE
  on Tutors
  for each row
BEGIN

        INSERT INTO Tutors_deleted(`UserWhoDelete`, `DeleteDate`, `TutorID`, `FirstName`, `LastName`, `Rating`,
                                   `UserID`)
        VALUES(USER(), NOW(), OLD.`TutorID`, OLD.`FirstName`, OLD.`LastName`, OLD.`Rating`, OLD.`UserID`);

        END;

