create
  definer = maksim@`%` procedure RegisterOrder(IN clientName varchar(50), IN tutorName varchar(50),
                                               IN subjName varchar(20), IN compName varchar(40), IN crsName varchar(30),
                                               IN orderStart datetime, IN orderEnd datetime, IN discID int)
`wholeProc`:
      BEGIN

        DECLARE currClientID INTEGER;
        DECLARE currLessonID INTEGER;
        DECLARE currTutorID INTEGER;
        DECLARE currSubjID INTEGER;
        DECLARE currCompanyID INTEGER;
        DECLARE currCourseID INTEGER;
        DECLARE currClientDiscount FLOAT(3,2);
        DECLARE currDiscountValue INTEGER;
        DECLARE currPrice FLOAT(6,2);
        DECLARE finalPrice FLOAT(6,2);

        SELECT `TutorID` FROM Tutors
          WHERE CONCAT(Tutors.`FirstName`, ' ', Tutors.`LastName`) = tutorName
          INTO currTutorID;

        SELECT `SubjectID` FROM Subjects WHERE Subjects.`SubjectName` = subjName
          INTO currSubjID;

        SELECT `LessonID` FROM Lessons WHERE Lessons.TutorID = currTutorID AND Lessons.SubjectID = currSubjID
          INTO currLessonID;

        IF currLessonID IS NULL AND tutorName IS NOT NULL AND subjName IS NOT NULL THEN
          SELECT 'This tutor doesn\'t support given subject.';
          LEAVE `wholeProc`;
        END IF;

        SELECT `ClientID` FROM Clients
          WHERE CONCAT(Clients.`FirstName`, ' ', Clients.`LastName`) = clientName
          INTO currClientID;

        SELECT `CompanyID` FROM Companies WHERE Companies.`CompanyName` = compName
          INTO currCompanyID;

        SELECT `CourseID` FROM Courses WHERE Courses.`CourseName` = crsName
          INTO currCourseID;

        SELECT calculateClientDiscount(currClientID)
          INTO currClientDiscount;

        SELECT `DiscountValue` FROM Discounts WHERE Discounts.`DiscountID` = discID
          INTO currDiscountValue;

        IF currLessonID IS NOT NULL THEN
          SELECT `Price` FROM Subjects WHERE Subjects.`SubjectName` = subjName
            INTO currPrice;
        ELSE
          SELECT `Price` FROM Courses WHERE Courses.`CourseName` = crsName
            INTO currPrice;
        END IF;

        SET finalPrice = currPrice * (1 - currClientDiscount) * (1 - currDiscountValue);

        INSERT INTO Orders(`ClientID`, `LessonID`, `CompanyID`, `CourseID`, `StartDate`, `EndDate`, `Price`,
                           `DiscountID`, `ClientDiscount`)
        VALUES(currClientID, currLessonID, currCompanyID, currCourseID, orderStart, orderEnd, finalPrice, discID,
               currClientDiscount);

      END;

