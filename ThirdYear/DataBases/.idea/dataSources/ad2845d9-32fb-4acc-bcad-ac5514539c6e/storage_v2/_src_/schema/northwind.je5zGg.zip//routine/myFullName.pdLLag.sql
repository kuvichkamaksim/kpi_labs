create
  definer = root@localhost procedure myFullName()
SELECT 'Kuvichka Maksim Evhenovych';

