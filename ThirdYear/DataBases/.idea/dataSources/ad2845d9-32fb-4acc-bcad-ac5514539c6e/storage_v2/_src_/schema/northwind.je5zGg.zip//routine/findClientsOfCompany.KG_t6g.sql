create
  definer = root@localhost procedure findClientsOfCompany(IN company varchar(40))
BEGIN
 SELECT Customers.CompanyName FROM Customers
 JOIN Orders ON Customers.CustomerID = Orders.CustomerID
 JOIN Shippers ON Orders.ShipVia = Shippers.ShipperID
 WHERE Shippers.CompanyName = company;
END;

