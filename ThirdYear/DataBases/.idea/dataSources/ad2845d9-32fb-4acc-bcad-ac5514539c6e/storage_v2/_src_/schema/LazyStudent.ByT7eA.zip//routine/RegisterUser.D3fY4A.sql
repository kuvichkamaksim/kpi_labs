create
  definer = maksim@`%` procedure RegisterUser(IN type varchar(6), IN userLogin varchar(30), IN userPassword varchar(30),
                                              IN fName varchar(20), IN lName varchar(30), IN phone varchar(15),
                                              IN email varchar(30), IN secondPhone varchar(15))
BEGIN

        IF type = 'Client' THEN

          INSERT INTO Users(`UserType`, `Login`, `Password`, `PhoneNumber`, `E-mail`, `ReservePhoneNumber`)
            VALUES(type, userLogin, userPassword, phone, email, secondPhone);

          INSERT INTO Clients(`LastName`, `FirstName`, `UserID`)
            VALUES(lName, fName, LAST_INSERT_ID());

        ELSEIF type = 'Tutor' THEN

          INSERT INTO Users(`UserType`, `Login`, `Password`, `PhoneNumber`, `E-mail`, `ReservePhoneNumber`)
           VALUES(type, userLogin, userPassword, phone, email, secondPhone);

          INSERT INTO Tutors(`LastName`, `FirstName`, `UserID`)
           VALUES(lName, fName, LAST_INSERT_ID());

        ELSE SELECT 'Incorrect user type!';

        END IF;

      END;

