create
  definer = maksim@`%` procedure IncomePerPeriod(IN startDate datetime, IN endDate datetime)
BEGIN

        IF startDate IS NULL THEN
          SET startDate = NOW();
        ELSEIF endDate IS NULL THEN
          SET endDate = NOW();
        END IF;

        SELECT * FROM Orders WHERE Orders.StartDate BETWEEN startDate AND endDate;

      END;

