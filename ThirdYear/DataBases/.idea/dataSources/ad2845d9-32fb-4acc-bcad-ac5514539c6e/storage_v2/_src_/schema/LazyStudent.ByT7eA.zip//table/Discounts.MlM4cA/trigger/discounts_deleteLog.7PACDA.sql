create definer = maksim@`%` trigger discounts_deleteLog
  after DELETE
  on Discounts
  for each row
BEGIN

        INSERT INTO Discounts_deleted(`UserWhoDelete`, `DeleteDate`, `DiscountID`, `DiscountValue`, `CompanyID`,
                                      `InsertionDate`, `StartDate`, `EndDate`)
        VALUES(USER(), NOW(), OLD.`DiscountID`, OLD.`DiscountValue`, OLD.`CompanyID`, OLD.`InsertionDate`, OLD.`StartDate`,
               OLD.`EndDate`);

        END;

