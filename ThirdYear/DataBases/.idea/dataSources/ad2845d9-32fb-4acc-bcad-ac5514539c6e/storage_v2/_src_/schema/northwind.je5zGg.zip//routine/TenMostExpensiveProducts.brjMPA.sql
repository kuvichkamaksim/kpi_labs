create
  definer = root@localhost procedure TenMostExpensiveProducts()
BEGIN

  SELECT Products.*, Shippers.CompanyName, Categories.CategoryName
  FROM Products
  JOIN Shippers ON Products.SupplierID = Shippers.ShipperID
  JOIN Categories ON Products.CategoryID = Categories.CategoryID
  ORDER BY UnitPrice DESC
  LIMIT 10;

END;

