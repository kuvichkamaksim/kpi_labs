create
  definer = root@localhost procedure selectProductsByCategory(IN category1 varchar(15), IN category2 varchar(15),
                                                              IN category3 varchar(15), IN category4 varchar(15),
                                                              IN category5 varchar(15))
BEGIN

  SELECT Products.ProductName,
    Categories.CategoryName FROM Products JOIN Categories
    ON Products.CategoryID = Categories.CategoryID
    WHERE Categories.CategoryName IN (category1, category2, category3,
                                      category4, category5);

END;

