create
  definer = maksim@`%` procedure getOrderStatus(IN currOrderID int)
BEGIN

        DECLARE start DATETIME;
        DECLARE end DATETIME;

        SELECT `StartDate`, `EndDate` FROM Orders WHERE Orders.`OrderID` = currOrderID
          INTO start, end;

        IF NOW() < start THEN
          SELECT 'Ordered';
        ELSEIF NOW() > start AND NOW() > end THEN
          SELECT 'Active';
        ELSE
          SELECT 'Finished';
        END IF;

      END;

