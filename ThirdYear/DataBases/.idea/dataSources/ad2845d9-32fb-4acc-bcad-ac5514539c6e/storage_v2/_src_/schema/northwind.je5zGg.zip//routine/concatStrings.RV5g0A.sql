create
  definer = root@localhost function concatStrings(TitleOfCourtesy varchar(20), FirstName varchar(20),
                                                  LastName varchar(20)) returns varchar(63)
RETURN CONCAT(TitleOfCourtesy, ' ', FirstName, ' ', LastName);

