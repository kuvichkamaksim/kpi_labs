create
  definer = maksim@`%` procedure RegisterLesson(IN tutorName varchar(50), IN subjName varchar(20))
BEGIN

        DECLARE currTutorID INTEGER;
        DECLARE currSubjID INTEGER;

        SELECT `TutorID` FROM Tutors WHERE CONCAT(`FirstName`, ' ', `LastName`) = tutorName INTO currTutorID;
        SELECT `SubjectID` FROM Subjects WHERE `SubjectName` = subjName INTO currSubjID;

        INSERT INTO Lessons(`TutorID`, `SubjectID`)
          VALUES(currTutorID, currSubjID);

      END;

